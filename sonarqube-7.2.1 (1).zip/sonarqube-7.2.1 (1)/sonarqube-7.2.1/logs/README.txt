This directory contains log files. See advanced configuration in conf/sonar.properties.
